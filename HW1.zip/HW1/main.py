def main():
    print('Hello, I am the main function')


if __name__ == '__main__':
    main()